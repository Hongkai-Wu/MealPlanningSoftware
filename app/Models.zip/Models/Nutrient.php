<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany; // <--- 导入 BelongsToMany

/**
 * 营养成分模型 (Nutrient Model)
 * 对应数据库中的 nutrients 表
 */
class Nutrient extends Model
{
    use HasFactory;

    /**
     * 可批量赋值的属性 (Mass assignable attributes)
     * @var array<int, string>
     */
    protected $fillable = [
        'name',
        'unit',
    ];

    /**
     * 营养成分与食谱的多对多关系 (Many-to-Many with Recipe)
     * 通过 recipe_nutrients 中间表连接
     */
    public function recipes(): BelongsToMany // <--- 推荐添加返回类型声明
    {
        // 关键：将 'quantity' 改为 'amount'，以匹配数据库中的字段
        return $this->belongsToMany(Recipe::class, 'recipe_nutrient') // 确保中间表名与迁移文件一致
                    ->withPivot('amount'); // <--- 已修正为 'amount'
    }

    /**
     * 营养成分与用户目标的一对多关系 (One-to-Many with UserGoal)
     * 一个营养成分可以被多个用户目标引用
     */
    public function userGoals()
    {
        // 假设 UserGoal 模型已经定义
        return $this->hasMany(UserGoal::class);
    }
}
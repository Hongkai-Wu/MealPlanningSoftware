<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Recipe extends Model
{
    use HasFactory;

    /**
     * 可批量赋值的属性。
     * 确保您在 Seeder 中插入的字段都在这里。
     */
    protected $fillable = [
        'name',
        'description',
        'calories',
        'protein',
        'fat',
        'carbs',
        'estimated_time', // 如果您之前定义了这些字段
        'servings', // 如果您之前定义了这些字段
    ];

    /**
     * 食谱可以被多个 MealLog 记录引用 (一对多关系)。
     */
    public function mealLogs()
    {
        return $this->hasMany(MealLog::class);
    }

    /**
     * 食谱可以关联多种营养素 (多对多关系)。
     */
    public function nutrients()
    {
        return $this->belongsToMany(Nutrient::class, 'recipe_nutrient')
                    ->withPivot('amount');
    }

    /**
     * 食谱可以属于一个用户 (可选，如果您启用了用户关联)
     */
    // public function user()
    // {
    //     return $this->belongsTo(User::class);
    // }
}